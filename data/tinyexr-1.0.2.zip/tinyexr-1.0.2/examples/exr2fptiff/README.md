# exr2fptiff

OpenEXR to 32bit float TIFF converter.

## Limitation

Input EXR image must be grayscale, RGB or RGBA.
