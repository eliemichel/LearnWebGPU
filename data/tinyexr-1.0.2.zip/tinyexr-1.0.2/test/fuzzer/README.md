# Test with llvm Fuzzer

## Requirements

clang 12 or later
(recent clang does not require libFuzzer anymore)

## Compile and run

```
$ make
$ make t
```

## TODO

* Move to use Catch unit test framework
