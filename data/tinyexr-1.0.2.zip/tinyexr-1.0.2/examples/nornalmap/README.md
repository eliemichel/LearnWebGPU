# Normal map generation tool

Load bump or vector displacement map and convert it to normal map.
(For vector displacement map, it generates approximated normal map)


## TODO

* [ ] Mip map generation with normal map prefiltering

## Licenses

* cxxopts.hpp : Copyright (c) 2014, 2015, 2016, 2017 Jarryd Beck. MIT license.
