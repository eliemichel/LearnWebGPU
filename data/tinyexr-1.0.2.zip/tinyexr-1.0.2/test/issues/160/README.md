Reproducible script for issue #160(PIZ huffman decode issue)
