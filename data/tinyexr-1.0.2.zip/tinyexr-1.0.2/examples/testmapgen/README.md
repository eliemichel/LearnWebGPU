# Test EXR image map gen

Generate test EXR images for envmap test, composition test, etc.

* white(R=1, G=1, B=1)
* white10(R=10, G=10, B=10)
* white100(R=100, G=100, B=100)


## TODO

* [ ] red(R=1, G=0, B=0)
* [ ] green(R=0, G=1, B=0)
* [ ] blue(R=0, G=0, B=1)
* [ ] longlat test image
